
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kuanyinchen',
  applicationName: 'my-first-app',
  appUid: 'vk4CLRhNJwfvPXr84k',
  orgUid: '939e9e31-d749-4af9-b4fa-6bc8bfa7289b',
  deploymentUid: 'e3ffda64-9091-4b38-9e7e-7bdf2ca130a4',
  serviceName: 'api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'api-dev-app-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}
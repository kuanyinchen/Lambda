const express = require('express');
const router = require('express').Router();

router.get('/', (req, res) => {
    res.status(200).send('Hello Serverless!');
});

module.exports = router;
